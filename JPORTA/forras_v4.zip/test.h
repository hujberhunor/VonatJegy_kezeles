#ifndef TEST_H
#define TEST_H

  void mav_test();
  void vonat_test();


#endif // !TEST_H
